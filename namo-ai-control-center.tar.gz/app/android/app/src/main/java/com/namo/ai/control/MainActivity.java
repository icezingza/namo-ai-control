package com.namo.ai.control;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
