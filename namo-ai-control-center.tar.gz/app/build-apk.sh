#!/bin/bash

# Build APK Script for Namo AI Control Center
# สคริปต์นี้ใช้สำหรับสร้างไฟล์ APK บนเครื่องที่ติดตั้ง Java และ Android SDK แล้ว

echo "=========================================="
echo "  Building Namo AI Control Center APK"
echo "=========================================="
echo ""

# Check prerequisites
check_command() {
    if ! command -v $1 &> /dev/null; then
        echo "❌ Error: $1 is not installed"
        return 1
    fi
    echo "✅ $1 is installed"
    return 0
}

echo "Checking prerequisites..."
check_command node || exit 1
check_command npm || exit 1
check_command java || exit 1

echo ""
echo "Step 1: Installing dependencies..."
npm install

echo ""
echo "Step 2: Building web application..."
npm run build

echo ""
echo "Step 3: Syncing Capacitor with Android..."
npx cap sync android

echo ""
echo "Step 4: Building Debug APK..."
cd android
./gradlew assembleDebug

if [ $? -eq 0 ]; then
    echo ""
    echo "=========================================="
    echo "  ✅ Build Successful!"
    echo "=========================================="
    echo ""
    echo "APK Location:"
    echo "  Debug:   $(pwd)/app/build/outputs/apk/debug/app-debug.apk"
    echo ""
    echo "Install on tablet:"
    echo "  adb install $(pwd)/app/build/outputs/apk/debug/app-debug.apk"
    echo ""
else
    echo ""
    echo "=========================================="
    echo "  ❌ Build Failed!"
    echo "=========================================="
    exit 1
fi
