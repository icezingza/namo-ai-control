# วิธีสร้างไฟล์ APK สำหรับ Namo AI Control Center

## วิธีที่ 1: ใช้ GitHub Actions (แนะนำ - ง่ายที่สุด)

### ขั้นตอน:
1. สร้าง Repository บน GitHub
2. Push โค้ดนี้ขึ้น GitHub:
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/namo-ai-control.git
git push -u origin main
```
3. GitHub Actions จะ build APK อัตโนมัติ
4. ดาวน์โหลด APK จากหน้า **Actions** → **Build Android APK** → **Artifacts**

---

## วิธีที่ 2: ใช้ Android Studio

### ขั้นตอน:
1. ติดตั้ง [Android Studio](https://developer.android.com/studio)
2. เปิดโฟลเดอร์ `android` ใน Android Studio
3. รอให้ Gradle sync เสร็จ
4. ไปที่ **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**
5. APK จะอยู่ที่ `android/app/build/outputs/apk/debug/app-debug.apk`

---

## วิธีที่ 3: ใช้ Docker

### ขั้นตอน:
```bash
# Build Docker image
docker build -t namo-ai-builder .

# Run build
docker run -v $(pwd)/output:/output namo-ai-builder

# APK จะอยู่ที่ ./output/app-debug.apk
```

---

## วิธีที่ 4: ใช้ Command Line (ต้องติดตั้ง Java และ Android SDK)

### ความต้องการ:
- Node.js 20+
- Java JDK 17
- Android SDK

### ขั้นตอน:
```bash
# 1. ติดตั้ง dependencies
npm install

# 2. Build web app
npm run build

# 3. Sync Capacitor
npx cap sync android

# 4. Build APK
cd android
./gradlew assembleDebug

# APK จะอยู่ที่ android/app/build/outputs/apk/debug/app-debug.apk
```

---

## การติดตั้ง APK ลงแท็บเล็ต

### ขั้นตอน:
1. เปิด **Settings** บนแท็บเล็ต Android
2. ไปที่ **Security** → เปิด **Unknown Sources** (หรือ **Install unknown apps**)
3. โอนไฟล์ APK เข้าแท็บเล็ต (ผ่าน USB, Google Drive, หรือ Bluetooth)
4. แตะไฟล์ APK เพื่อติดตั้ง
5. เปิดแอป **Namo AI Control Center**

---

## การตั้งค่าเซิร์ฟเวอร์

เมื่อเปิดแอปครั้งแรก:
1. แตะไอคอน **Settings** (ฟันเฟือง) ที่มุมขวาบน
2. ใส่ **Server IP Address** (IP ของ Lenovo Laptop)
3. ใส่ **Port** (ค่าเริ่มต้น: 8080)
4. แตะ **Save**
5. แอปจะเชื่อมต่อกับเซิร์ฟเวอร์อัตโนมัติ

---

## โครงสร้างโปรเจค

```
namo-ai-control/
├── android/              # Android project (Capacitor)
├── src/                  # React source code
├── dist/                 # Built web app
├── capacitor.config.ts   # Capacitor config
└── .github/workflows/    # GitHub Actions
```

## หมายเหตุ

- **Debug APK**: ใช้สำหรับทดสอบ ติดตั้งได้ทันที
- **Release APK**: ต้องเซ็นลายเซ็น (sign) ก่อนใช้งานจริง
